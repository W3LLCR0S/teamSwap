package com.teamswap.projet_teamswap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetTeamswapApplicationTests {

	@Test
	void contextLoads() {
	}

}
