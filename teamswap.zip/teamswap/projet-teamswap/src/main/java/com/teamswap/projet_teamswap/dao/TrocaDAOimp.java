package com.teamswap.projet_teamswap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import com.teamswap.projet_teamswap.config.ConexaoBanco;
import com.teamswap.projet_teamswap.model.Sede;
import com.teamswap.projet_teamswap.model.Troca;
import com.teamswap.projet_teamswap.model.User;
import jakarta.servlet.http.HttpServletRequest;

@Repository
public class TrocaDAOimp implements TrocaDAO {
    @Override
    public boolean solicitarTroca(HttpServletRequest request, int novaSedeId) throws SQLException {
        // Recupera o usuário logado da sessão
        User usuario = (User) request.getSession().getAttribute("usuario");

        if (usuario == null) {
            System.out.println("Usuário não está logado!");
            return false;
        }

        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = "INSERT INTO troca (usuario_id, sede_desejada) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, usuario.getId());
                stmt.setInt(2, novaSedeId); // nova sede desejada

                int linhasAfetadas = stmt.executeUpdate();
                return linhasAfetadas > 0;
            }
        }
    }

    @Override
    public boolean editarTroca(int idSolicitacao, int novaSedeId) throws SQLException {
        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = "UPDATE troca SET sede_desejada = ? WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, novaSedeId);
                stmt.setInt(2, idSolicitacao);
                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    @Override
    public boolean excluirTroca(int idSolicitacaoExcluir) throws SQLException {
        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = "DELETE FROM troca WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idSolicitacaoExcluir);
                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    @Override
    public List<Troca> exibirSolicitacao(HttpServletRequest request, int id) throws SQLException {
        User usuario = (User) request.getSession().getAttribute("usuario");

        String sql = """
                        SELECT t.id AS troca_id, s1.nome AS nome_sede_origem, s2.nome AS nome_sede_destino
                        FROM troca t
                        JOIN usuarios u ON t.usuario_id = u.id
                        JOIN sedes s1 ON u.sede_id = s1.id
                        JOIN sedes s2 ON t.sede_desejada = s2.id
                        WHERE t.usuario_id = ?
                    """;

        List<Troca> solicitacoes = new ArrayList<>();

        try (Connection conn = ConexaoBanco.conectar();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, usuario.getId());

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Troca troca = new Troca();

                    // Agora que você criou o setId, pode setar o ID
                    troca.setId(rs.getInt("troca_id"));

                    // Cria e seta a sede de origem
                    Sede sedeOrigem = new Sede();
                    sedeOrigem.setNome(rs.getString("nome_sede_origem"));

                    // Cria e seta a sede desejada
                    Sede sedeDesejada = new Sede();
                    sedeDesejada.setNome(rs.getString("nome_sede_destino"));

                    // Associa o usuário e as sedes à troca
                    troca.setUsuario(usuario);
                    troca.setSedeDesejada(sedeDesejada);
                    solicitacoes.add(troca);
                }

                // Seta a lista no request para a view
                request.setAttribute("solicitacoes", solicitacoes);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return solicitacoes;
    }

}
