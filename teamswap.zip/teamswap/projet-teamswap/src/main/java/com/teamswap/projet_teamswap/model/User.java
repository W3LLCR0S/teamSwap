package com.teamswap.projet_teamswap.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "role", discriminatorType = DiscriminatorType.STRING)
public abstract class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false, unique = true)
    private String login; // CPF

    @Column(nullable = false)
    private String senha; // já criptografada

    @Column(nullable = false)
    public String role; // colaborador ou gestor

    @Column(nullable = false)
    private String cargo;

    @Lob
    @Column(nullable = false)
    private byte[] foto;

    @ManyToOne
    @JoinColumn(name = "sede_id", nullable = false)
    private Sede sede;

    // --- Construtores ---

    public User() {
    }

    public User(String nome, String email, String login, String senha, String role, String cargo, byte[] foto, Sede sede) {
        this.nome = nome;
        this.email = email;
        this.login = login;
        this.senha = senha;
        this.role = role;
        this.cargo = cargo;
        this.foto = foto;
        this.sede = sede;
    }

    // --- Getters e Setters ---

    public Integer getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getLogin() {
        return login;
    }

    public String getSenha() {
        return senha;
    }

    public String getRole() {
        return role;
    }

    public String getCargo() {
        return cargo;
    }

    public byte[] getFoto() {
        return foto;
    }

    public Sede getSede() {
        return sede;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setSede(Sede sede) {
        this.sede = sede;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
     
    public void setCpf(String login) {
        this.login = login;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // --- Métodos de atualização de perfil ---

    public void atualizarPerfil(String novoEmail, String novoLogin, String novaSenhaCriptografada, byte[] novaFoto) {
        setEmail(novoEmail);
        setLogin(novoLogin);
        setSenha(novaSenhaCriptografada);
        setFoto(novaFoto);
    }
}

