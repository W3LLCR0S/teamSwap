package com.teamswap.projet_teamswap.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.teamswap.projet_teamswap.config.ConexaoBanco;
import com.teamswap.projet_teamswap.dao.UserDAOimp;
import com.teamswap.projet_teamswap.model.User;
import com.teamswap.projet_teamswap.model.Colaborador;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class UpdateController {
    @Autowired
    private UserDAOimp userDAOimp;

    @PostMapping("/updateUser")
    public String updateUsers(
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String senha,
            @RequestParam(required = false) String antigaSenha,
            @RequestParam(name = "foto", required = false) MultipartFile foto, // Aqui recebemos o arquivo
            Model model,
            HttpServletRequest request) {

        try {
            byte[] fotoBytes = null;
            if (!foto.isEmpty()) {
                fotoBytes = foto.getBytes();
            }

            boolean atualizado = userDAOimp.atualizar(email, antigaSenha, senha, fotoBytes); // novo método

            if (atualizado) {
                User usuario = userDAOimp.login(email, senha);
                model.addAttribute("usuario", usuario);
                model.addAttribute("mensagem", "Usuário atualizado com sucesso");
                return "redirect:/index";
            } else {
                model.addAttribute("erro", "Usuário não encontrado");
                return "index";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("erro", "Erro inesperado");
            return "index";
        }
    }

}