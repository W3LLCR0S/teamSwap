package com.teamswap.projet_teamswap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.teamswap.projet_teamswap.model.Sede;
import com.teamswap.projet_teamswap.config.ConexaoBanco;
import java.sql.*;

public class SedeDAO {
    private Connection conn;

    public SedeDAO(Connection conn) {
        this.conn = conn;
    }

    public Sede buscarPorId(int id) {
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM sedes WHERE id = ?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Sede sede = new Sede();
                sede.setId(rs.getLong("id"));
                sede.setNome(rs.getString("nome"));
                return sede;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
