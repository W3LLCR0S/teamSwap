package com.teamswap.projet_teamswap.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.teamswap.projet_teamswap.dao.TrocaDAOimp;
import com.teamswap.projet_teamswap.model.Troca;
import com.teamswap.projet_teamswap.model.User;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ColaboradorController {
    @GetMapping("/colaborador")
public String mostrarPaginaColaborador(HttpServletRequest request, Model model) throws SQLException {
    User usuario = (User) request.getSession().getAttribute("usuario");

    if (usuario != null) {
        model.addAttribute("usuario", usuario);

        if (usuario.getFoto() != null) {
            String fotoBase64 = java.util.Base64.getEncoder().encodeToString(usuario.getFoto());
            model.addAttribute("fotoBase64", fotoBase64);
        }

        // Adiciona as solicitações ao modelo
        TrocaDAOimp trocaDAO = new TrocaDAOimp();
        List<Troca> solicitacoes = trocaDAO.exibirSolicitacao(request, usuario.getId());
        model.addAttribute("solicitacoes", solicitacoes);

        return "colaborador";
    }

    return "index"; // Usuário não está logado, redireciona para login
}

}
