package com.teamswap.projet_teamswap.model;

import jakarta.persistence.*;

@Entity
@Table(name = "troca")
public class Troca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private User usuario;

    @ManyToOne
    @JoinColumn(name = "sede_desejada")
    private Sede sedeDesejada;

    public Troca() {}

    public Troca(User usuario, Sede sedeDesejada) {
        this.usuario = usuario;
        this.sedeDesejada = sedeDesejada;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public User getUsuario() {
        return usuario;
    }

    public void setUsuario(User usuario) {
        this.usuario = usuario;
    }

    public Sede getSedeDesejada() {
        return sedeDesejada;
    }

    public void setSedeDesejada(Sede sedeDesejada) {
        this.sedeDesejada = sedeDesejada;
    }
}
