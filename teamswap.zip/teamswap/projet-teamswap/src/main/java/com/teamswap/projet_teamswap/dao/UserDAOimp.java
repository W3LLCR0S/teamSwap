package com.teamswap.projet_teamswap.dao;

import com.teamswap.projet_teamswap.model.Colaborador;
import com.teamswap.projet_teamswap.model.Gestor;
import com.teamswap.projet_teamswap.model.Sede;
import com.teamswap.projet_teamswap.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.teamswap.projet_teamswap.config.ConexaoBanco;
import org.springframework.stereotype.Repository;
import com.teamswap.projet_teamswap.model.User;

@Repository
public class UserDAOimp implements UserDAO {
    @Override
    public boolean atualizar(String email, String senhaAntiga, String novaSenha, byte[] foto) throws SQLException {
        try (Connection conn = ConexaoBanco.conectar();
                PreparedStatement stmtVerificacao = conn
                        .prepareStatement("SELECT senha FROM usuarios WHERE email = ?")) {

            stmtVerificacao.setString(1, email);
            try (ResultSet rs = stmtVerificacao.executeQuery()) {
                if (rs.next()) {
                    String senhaBanco = rs.getString("senha");

                    if (senhaBanco.equals(senhaAntiga)) {
                        String sql = "UPDATE usuarios SET senha = ?, foto_perfil = ? WHERE email = ?";
                        try (PreparedStatement stmtAtualizacao = conn.prepareStatement(sql)) {
                            stmtAtualizacao.setString(1, novaSenha);
                            stmtAtualizacao.setBytes(2, foto);
                            stmtAtualizacao.setString(3, email);

                            int rowsUpdated = stmtAtualizacao.executeUpdate();
                            return rowsUpdated > 0;
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override
    public User login(String email, String senha) throws SQLException {
        User usuario = null;
        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = "SELECT * FROM usuarios WHERE email = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String senhaBanco = rs.getString("senha");
                    String role = rs.getString("role");

                    if (senhaBanco.equals(senha)) {
                        if ("gestor".equalsIgnoreCase(role)) {
                            usuario = new Gestor();
                            usuario.setId(rs.getInt("id"));
                            usuario.setNome(rs.getString("nome"));
                            usuario.setEmail(rs.getString("email"));
                            usuario.setCpf(rs.getString("login"));
                            usuario.setSenha(rs.getString("senha"));
                            usuario.setRole(rs.getString("role"));
                            usuario.setCargo(rs.getString("cargo"));
                            usuario.setFoto(rs.getBytes("foto_perfil"));

                            // Supondo que você tenha uma instância do DAO de sede
                            SedeDAO sedeDAO = new SedeDAO(conn); // conn = conexão JDBC atual
                            Sede sede = sedeDAO.buscarPorId(rs.getInt("sede_id"));
                            usuario.setSede(sede);
                            return usuario;
                        } else if ("colaborador".equalsIgnoreCase(role)) {
                            usuario = new Colaborador();
                            usuario.setId(rs.getInt("id"));
                            usuario.setNome(rs.getString("nome"));
                            usuario.setEmail(rs.getString("email"));
                            usuario.setCpf(rs.getString("login"));
                            usuario.setSenha(rs.getString("senha"));
                            usuario.setRole(rs.getString("role"));
                            usuario.setCargo(rs.getString("cargo"));
                            usuario.setFoto(rs.getBytes("foto_perfil"));

                            // Supondo que você tenha uma instância do DAO de sede
                            SedeDAO sedeDAO = new SedeDAO(conn); // conn = conexão JDBC atual
                            Sede sede = sedeDAO.buscarPorId(rs.getInt("sede_id"));
                            usuario.setSede(sede);
                            return usuario;
                        }

                    }
                }
            }
        }
        return null;
    }

    
}