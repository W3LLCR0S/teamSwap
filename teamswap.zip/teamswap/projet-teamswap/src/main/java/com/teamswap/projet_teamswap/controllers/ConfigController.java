package com.teamswap.projet_teamswap.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import com.teamswap.projet_teamswap.model.User;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ConfigController {
    @GetMapping("/config")
    public String config(HttpServletRequest request, Model model) {
        User usuario = (User) request.getSession().getAttribute("usuario");

        if (usuario != null) {
            model.addAttribute("usuario", usuario);

            if (usuario.getFoto() != null) {
                String fotoBase64 = java.util.Base64.getEncoder().encodeToString(usuario.getFoto());
                model.addAttribute("fotoBase64", fotoBase64);
            }

            return "config";
        }

        return "index"; // Usuário não está logado, redireciona para login
    }
}
