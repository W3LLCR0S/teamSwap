package com.teamswap.projet_teamswap.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "matchs")
public class Match {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Desejo 1 (Troca)
    @ManyToOne(optional = false)
    @JoinColumn(name = "desejo1_id", nullable = false)
    private Troca desejo1;

    // Desejo 2 (Troca)
    @ManyToOne(optional = false)
    @JoinColumn(name = "desejo2_id", nullable = false)
    private Troca desejo2;

    @Column(nullable = false)
    private String status = "pendente";

    @Column(name = "data_criacao", nullable = false)
    private LocalDateTime dataCriacao = LocalDateTime.now();

    // Construtores
    public Match() {
    }

    public Match(Troca desejo1, Troca desejo2, String status) {
        this.desejo1 = desejo1;
        this.desejo2 = desejo2;
        this.status = status;
        this.dataCriacao = LocalDateTime.now();
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public Troca getDesejo1() {
        return desejo1;
    }

    public void setDesejo1(Troca desejo1) {
        this.desejo1 = desejo1;
    }

    public Troca getDesejo2() {
        return desejo2;
    }

    public void setDesejo2(Troca desejo2) {
        this.desejo2 = desejo2;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }
}
