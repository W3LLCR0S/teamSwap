package com.teamswap.projet_teamswap.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "colaborador")
public class Colaborador extends User {

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL)
    private List<Troca> solicitacoes = new ArrayList<>();

    public Colaborador() {
        this.solicitacoes = new ArrayList<>();
        setRole("colaborador");
    }

    public Colaborador(String nome, String email, String login, String senha, String cargo, byte[] foto, Sede sede) {
        super(nome, email, login, senha, "colaborador", cargo, foto, sede);
        this.solicitacoes = new ArrayList<>();
    }

    public List<Troca> getSolicitacoes() {
        return solicitacoes;
    }

    public void setSolicitacoes(List<Troca> solicitacoes) {
        this.solicitacoes = solicitacoes;
    }

    public void criarSolicitacao(Troca troca) {
        if (solicitacoes == null) {
            solicitacoes = new ArrayList<>();
        }
        solicitacoes.add(troca);
    }

    public List<Troca> verSolicitacoes() {
        return solicitacoes;
    }

    public boolean atualizarSolicitacao(Troca trocaAtualizada) {
        for (int i = 0; i < solicitacoes.size(); i++) {
            if (solicitacoes.get(i).getId().equals(trocaAtualizada.getId())) {
                solicitacoes.set(i, trocaAtualizada);
                return true;
            }
        }
        return false;
    }

    public void deletarSolicitacao(Troca troca) {
        solicitacoes.removeIf(t -> t.getId().equals(troca.getId()));
    }
}
