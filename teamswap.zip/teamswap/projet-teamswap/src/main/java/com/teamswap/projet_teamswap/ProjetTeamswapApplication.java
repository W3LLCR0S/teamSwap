package com.teamswap.projet_teamswap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetTeamswapApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetTeamswapApplication.class, args);
	}

}
