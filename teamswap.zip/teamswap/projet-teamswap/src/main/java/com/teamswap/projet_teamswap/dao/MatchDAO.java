package com.teamswap.projet_teamswap.dao;

import java.sql.SQLException;

import com.teamswap.projet_teamswap.model.Match;
import jakarta.servlet.http.HttpServletRequest;

public interface MatchDAO {
    public boolean fazerMatch();
    public boolean aceitarMatch();
    public boolean recusarMatch();

}