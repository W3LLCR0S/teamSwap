package com.teamswap.projet_teamswap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import org.springframework.stereotype.Repository;
import com.teamswap.projet_teamswap.config.ConexaoBanco;
import com.teamswap.projet_teamswap.model.Colaborador;
import com.teamswap.projet_teamswap.model.Sede;
import com.teamswap.projet_teamswap.model.User;
import jakarta.servlet.http.HttpServletRequest;

@Repository
public class MatchDAOimp {
    public static List<List<User>> encontrarMatchs() throws SQLException {
        List<List<User>> matchs = new ArrayList<>();

        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = """
                        SELECT
                            u1.id AS id_usuario1,
                            u1.nome AS nome_usuario1,
                            u1.sede_id AS sede_atual_usuario1,
                            s1.nome AS nome_sede_usuario1,
                            u2.id AS id_usuario2,
                            u2.nome AS nome_usuario2,
                            u2.sede_id AS sede_atual_usuario2,
                            s2.nome AS nome_sede_usuario2
                        FROM
                            Troca t1
                        JOIN Usuarios u1 ON t1.usuario_id = u1.id
                        JOIN Troca t2 ON t1.usuario_id <> t2.usuario_id
                        JOIN Usuarios u2 ON t2.usuario_id = u2.id
                            AND t1.sede_desejada = u2.sede_id
                            AND t2.sede_desejada = u1.sede_id
                            AND u1.id < u2.id  -- <-- aqui está o filtro anti-duplicação
                        JOIN Sedes s1 ON u1.sede_id = s1.id
                        JOIN Sedes s2 ON u2.sede_id = s2.id
                        ORDER BY t1.sede_desejada
                        LIMIT 1000;
                    """;

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    User user1 = new Colaborador();
                    user1.setId(rs.getInt("id_usuario1"));
                    user1.setNome(rs.getString("nome_usuario1"));
                    SedeDAO sedeDAO = new SedeDAO(conn);
                    Sede sede = sedeDAO.buscarPorId(rs.getInt("sede_atual_usuario1"));
                    user1.setSede(sede);

                    User user2 = new Colaborador();
                    user2.setId(rs.getInt("id_usuario2"));
                    user2.setNome(rs.getString("nome_usuario2"));
                    Sede sede2 = sedeDAO.buscarPorId(rs.getInt("sede_atual_usuario2"));
                    user2.setSede(sede2);

                    List<User> parMatch = Arrays.asList(user1, user2);
                    matchs.add(parMatch);
                    System.out.println("Match encontrado: " + user1.getNome() + " <--> " + user2.getNome());
                }
            }
        }
        
        return matchs;
    }
    
    public static boolean aceitarMatch(int desejo1Id, int desejo2Id) throws SQLException {
        return registrarMatch(desejo1Id, desejo2Id, "aprovado");
    }

    
    public static boolean recusarMatch(int desejo1Id, int desejo2Id) throws SQLException {
        return registrarMatch(desejo1Id, desejo2Id, "rejeitado");
    }

    
    private static boolean registrarMatch(int desejo1Id, int desejo2Id, String status) throws SQLException {
        try (Connection conn = ConexaoBanco.conectar()) {
            String sql = "INSERT INTO matchs (desejo1_id, desejo2_id, status) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, desejo1Id);
                stmt.setInt(2, desejo2Id);
                stmt.setString(3, status);

                return stmt.executeUpdate() > 0;
            }
        }
    }

}