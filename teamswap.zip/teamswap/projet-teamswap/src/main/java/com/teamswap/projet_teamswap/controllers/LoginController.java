package com.teamswap.projet_teamswap.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpServletRequest;

import java.sql.SQLException;
import java.util.Base64;

import com.teamswap.projet_teamswap.model.User;
import com.teamswap.projet_teamswap.dao.UserDAOimp;

@Controller
public class LoginController {

    private final UserDAOimp userDAO = new UserDAOimp();

    @PostMapping("/login")
    public String autenticar(@RequestParam(required = false) String email,
                              @RequestParam(required = false) String senha,
                              Model model,
                              HttpServletRequest request) {
        try {
            User user = userDAO.login(email, senha);
            if (user != null) {
                // Salva o objeto completo do usuário na sessão
                request.getSession().setAttribute("usuario", user);

                // Converte a foto em base64
                String fotoBase64 = "";
                if (user.getFoto() != null) {
                    fotoBase64 = Base64.getEncoder().encodeToString(user.getFoto());
                }

                // Passa atributos para a view
                model.addAttribute("usuario", user);
                model.addAttribute("fotoBase64", fotoBase64);

                // Redireciona conforme o papel
                return "gestor".equalsIgnoreCase(user.getRole()) ? "redirect:/gestor" : "redirect:/colaborador";
            } else {
                model.addAttribute("erro", "credenciais"); // Credenciais inválidas
                return "index";
            }

        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("erro", "servidor"); // Erro de banco de dados
            return "index";
        }
    }
    
}
