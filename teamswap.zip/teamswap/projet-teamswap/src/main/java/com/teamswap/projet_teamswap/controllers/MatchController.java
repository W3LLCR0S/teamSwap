package com.teamswap.projet_teamswap.controllers;

import org.springframework.web.bind.annotation.*;

import com.teamswap.projet_teamswap.dao.MatchDAOimp;

import java.sql.SQLException;

@RestController
@RequestMapping("/match")
public class MatchController {

    @PostMapping("/aprovar")
    public String aprovarMatch(@RequestParam int desejo1, @RequestParam int desejo2) {
        try {
            boolean sucesso = MatchDAOimp.aceitarMatch(desejo1, desejo2);
            return sucesso ? "redirect:/gestor!" : "redirect:/gestor";
        } catch (SQLException e) {
            e.printStackTrace();
            return "index";
        }
    }

    @PostMapping("/rejeitar")
    public String rejeitarMatch(@RequestParam int desejo1, @RequestParam int desejo2) {
        try {
            boolean sucesso = MatchDAOimp.recusarMatch(desejo1, desejo2);
            return sucesso ? "redirect:/gestor" : "redirect:/gestor";
        } catch (SQLException e) {
            e.printStackTrace();
            return "index";
        }
    }
}
