package com.teamswap.projet_teamswap.dao;

import java.sql.SQLException;

import com.teamswap.projet_teamswap.model.User;
import jakarta.servlet.http.HttpServletRequest;

public interface UserDAO {

     public boolean atualizar(String email, String senhaAntiga, String novaSenha, byte[] foto) throws SQLException;
     public User login (String email, String senha)throws SQLException;
}