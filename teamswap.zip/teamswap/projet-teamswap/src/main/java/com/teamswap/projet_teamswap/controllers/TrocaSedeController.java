package com.teamswap.projet_teamswap.controllers;

import com.teamswap.projet_teamswap.dao.TrocaDAO;
import com.teamswap.projet_teamswap.dao.TrocaDAOimp;
import com.teamswap.projet_teamswap.dao.UserDAO;
import com.teamswap.projet_teamswap.model.Troca;
import com.teamswap.projet_teamswap.model.User;

import jakarta.servlet.http.HttpServletRequest;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class TrocaSedeController {

    @Autowired
    private TrocaDAOimp trocaDAOimp;

    @PostMapping("/solicitarTroca")
    public String solicitarTroca(@RequestParam("novaSedeId") int novaSedeId, HttpServletRequest request) {
        try {
            boolean sucesso = trocaDAOimp.solicitarTroca(request, novaSedeId);
            if (sucesso) {
                return "redirect:/colaborador";
            } else {
                return "index";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "index";
        }
    }

    @PostMapping("/editarTroca")
    public String editarTroca(@RequestParam("novaCidade") int novaCidade,
            @RequestParam("idSolicitacao") int solicitacaoId,
            HttpServletRequest request) {
        try {

            if (solicitacaoId <= 0 || novaCidade <= 0) {
                System.out.println("⚠️ Erro: IDs inválidos!");
                return "erro";
            }

            boolean sucesso = trocaDAOimp.editarTroca(solicitacaoId, novaCidade);
            return sucesso ? "redirect:/colaborador" : "redirect:/colaborador";
        } catch (Exception e) {
            e.printStackTrace();
            return "erro";
        }
    }

    @PostMapping("/excluirTroca")
    public String excluirTroca(@RequestParam("idSolicitacaoExcluir") int idSolicitacaoExcluir,
            HttpServletRequest request) {
        try {

            if (idSolicitacaoExcluir <= 0) {
                System.out.println("⚠️ Erro: IDs inválidos!");
                return "erro";
            }

            boolean sucesso = trocaDAOimp.excluirTroca(idSolicitacaoExcluir);
            return sucesso ? "redirect:/colaborador" : "redirect:/colaborador";
        } catch (Exception e) {
            e.printStackTrace();
            return "erro";
        }
    }

    @GetMapping("/exibirSolicitacao")
    public String exibirSolicitacao(HttpServletRequest request) {
        User usuario = (User) request.getSession().getAttribute("usuario");
         if (usuario != null) {
        int id = usuario.getId(); // ou getIdUsuario(), depende do nome do seu método
        try {
            trocaDAOimp.exibirSolicitacao(request, id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "redirect:/colaborador"; // substitua pelo nome correto do seu HTML
    } else {
        // Se não houver usuário na sessão, redireciona para o login, por exemplo
        return "redirect:/index";
    }

}
}