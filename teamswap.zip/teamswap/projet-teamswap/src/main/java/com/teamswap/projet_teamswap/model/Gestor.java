package com.teamswap.projet_teamswap.model;

import jakarta.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "gestor")
public class Gestor extends User {

    // Relacionamento com usuário
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    // Sede que o gestor gerencia
    @ManyToOne
    @JoinColumn(name = "sede_id")
    private Sede sedeResponsavel;

    public Gestor() {}

    public Gestor(String nome, String email, String login, String senha, String role, String cargo, byte[] foto, Sede sede, Sede sedeResponsavel) {
        super(nome, email, login, senha, role, cargo, foto, sede);
        this.sedeResponsavel = sedeResponsavel;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Sede getSedeResponsavel() {
        return sedeResponsavel;
    }

    public void setSedeResponsavel(Sede sedeResponsavel) {
        this.sedeResponsavel = sedeResponsavel;
    }

    // Ações possíveis

    public List<Match> verMatchs(List<Match> todosMatchs) {
        return todosMatchs.stream()
                .filter(m -> m.getDesejo1().getUsuario().getSede().equals(this.sedeResponsavel)
                        || m.getDesejo2().getUsuario().getSede().equals(this.sedeResponsavel))
                .collect(Collectors.toList());
    }

    public void aprovarMatch(Match match) {
        match.setStatus("aprovado");
    }

    public void recusarMatch(Match match) {
        match.setStatus("rejeitado");
    }
    
}
