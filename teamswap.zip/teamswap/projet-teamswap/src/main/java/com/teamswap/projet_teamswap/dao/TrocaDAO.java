package com.teamswap.projet_teamswap.dao;

import java.sql.SQLException;
import java.util.List;

import com.teamswap.projet_teamswap.model.Troca;
import jakarta.servlet.http.HttpServletRequest;

public interface TrocaDAO {
    public List<Troca> exibirSolicitacao(HttpServletRequest request, int id) throws SQLException;
    public boolean solicitarTroca(HttpServletRequest request, int novaSedeId) throws SQLException;
    public boolean editarTroca(int idSolicitacao, int novaSedeId)throws SQLException;
    public boolean excluirTroca(int idSolicitacaoExcluir) throws SQLException;
    
    
}