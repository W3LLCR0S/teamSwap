// Se o alert existir, desaparece depois de 4 segundos
window.onload = function () {
    const alertErro = document.getElementById('alert-erro');
    if (alertErro) {
        setTimeout(() => {
            alertErro.classList.add('hide');
        }, 4000); // 4 segundos visível
        // Remove do DOM depois da transição (1s)
        alertErro.addEventListener('transitionend', () => {
            alertErro.remove();
        });
    }
};