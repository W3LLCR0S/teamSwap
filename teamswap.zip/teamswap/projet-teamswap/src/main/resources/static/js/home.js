setTimeout(function () {
  window.location.href = "/index";
}, 3000);
