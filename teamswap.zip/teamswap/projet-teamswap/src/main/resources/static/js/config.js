document.getElementById("foto").addEventListener("change", function () {
    const file = this.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        document.getElementById("preview-foto").src = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  });
  
  document.getElementById("config-form").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const formData = new FormData(this);
    const foto = document.getElementById("foto").files[0];
    if (foto) formData.append("foto", foto);
  
    fetch("/PerfilConfigServlet", {
      method: "POST",
      body: formData
    })
      .then(res => res.text())
      .then(msg => {
        alert(msg);
      })
      .catch(err => console.error("Erro:", err));
  });
  