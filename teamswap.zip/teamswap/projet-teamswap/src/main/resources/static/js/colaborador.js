function mostrarFormulario(acao) {
  const area = document.getElementById('form-area');
  if (acao === 'criar') {
    area.innerHTML = `
          <h2>Criar Nova Solicitação</h2>
          <form class="input-form" action="/solicitarTroca" method="post">
            <select name="novaSedeId" id="novaSedeId">
              <option value="1">Londrina, PR</option>
              <option value="2">Curitiba, PR</option>
            </select>
            <button type="submit">Enviar Solicitação</button>
          </form>
        `;
  } else if (acao === 'editar') {
    area.innerHTML = `
          <h2>Editar Solicitação</h2>
          <form class="input-form" action="/editarTroca" method="post">
            <input type="text" name="idSolicitacao" placeholder="ID da Solicitação" required>
            <select name="novaCidade" id="novaCidade">
              <option value="1">Londrina, PR</option>
              <option value="2">Curitiba, PR</option>
            </select>
            <button type="submit">Salvar Alterações</button>
          </form>
        `;
  } else if (acao === 'excluir') {
    area.innerHTML = `
          <h2>Excluir Solicitação</h2>
          <form class="input-form" action="/excluirTroca" method="post">
            <input type="text" name="idSolicitacaoExcluir" placeholder="ID da Solicitação a Excluir" required>
            <button type="submit">Excluir Solicitação</button>
          </form>
        `;
  }
}
